// src/App.jsx
import React, { useState, useEffect } from 'react';
import './App.css';
import Navbar from './Components/Navbar';
import EventCard from './Components/EventCard';
import LoadingSpinner from './Components/EventModal';

const mockData = [
  { id: 1, name: "Music Concert", date: "2024-11-10", location: "New York", description: "An amazing music event."},
  { id: 2, name: "Art Exhibition", date: "2024-11-15", location: "San Francisco", description: "Explore modern art."},
  { id: 3, name: "Tech Meetup", date: "2024-11-20", location: "Chicago", description: "Network with tech enthusiasts."},
  // Add more events as needed
];

function App() {
  const [theme, setTheme] = useState('light');
  const [loading, setLoading] = useState(true); // New loading state

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false); // Simulate loading
    }, 2000); // Adjust time as needed

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`app ${theme}`}>
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="events-container">
          {mockData.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
