// src/components/Navbar.jsx
import React from 'react';
import '../styles/Navbar.css';

const Navbar = ({ theme, toggleTheme }) => {
  return (
    <nav className="navbar">
      <h1>EventSpot Lite</h1>
      <div className="theme-toggle">
        <button onClick={toggleTheme} className="toggle-button">
          {theme === 'light' ? '🌙 Dark' : '☀️ Light'}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
